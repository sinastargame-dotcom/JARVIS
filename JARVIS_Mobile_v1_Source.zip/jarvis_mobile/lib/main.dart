import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const JarvisApp());
}

enum JarvisLanguage { both, persian, english }

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JARVIS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050B16),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF38D9FF),
          secondary: Color(0xFF00A8D6),
          surface: Color(0xFF0B1728),
        ),
        useMaterial3: true,
      ),
      home: const JarvisHome(),
    );
  }
}

class ChatLine {
  final String text;
  final bool fromUser;
  ChatLine(this.text, this.fromUser);
}

class JarvisHome extends StatefulWidget {
  const JarvisHome({super.key});

  @override
  State<JarvisHome> createState() => _JarvisHomeState();
}

class _JarvisHomeState extends State<JarvisHome>
    with SingleTickerProviderStateMixin {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();

  late final AnimationController _pulse;
  final List<ChatLine> _messages = [
    ChatLine('JARVIS online. در خدمتم.', false),
  ];

  bool _speechReady = false;
  bool _listening = false;
  String _status = 'SYSTEM READY';
  String _recognized = '';
  JarvisLanguage _language = JarvisLanguage.both;

  bool get _isPersian => _language == JarvisLanguage.persian;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1700),
      lowerBound: 0.88,
      upperBound: 1.08,
    )..repeat(reverse: true);
    _initSpeech();
    _initTts();
  }

  Future<void> _initSpeech() async {
    try {
      final ready = await _speech.initialize(
        onStatus: (status) {
          if (!mounted) return;
          setState(() {
            _listening = status == 'listening';
            if (!_listening && _status == 'LISTENING') {
              _status = 'SYSTEM READY';
            }
          });
        },
        onError: (error) {
          if (!mounted) return;
          setState(() {
            _listening = false;
            _status = 'MICROPHONE ERROR';
          });
        },
      );
      if (!mounted) return;
      setState(() {
        _speechReady = ready;
        _status = ready ? 'SYSTEM READY' : 'SPEECH UNAVAILABLE';
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _status = 'SPEECH UNAVAILABLE');
    }
  }

  Future<void> _initTts() async {
    await _tts.setSpeechRate(0.46);
    await _tts.setPitch(0.92);
    await _tts.setVolume(1.0);
    await _tts.awaitSpeakCompletion(true);
  }

  @override
  void dispose() {
    _pulse.dispose();
    _input.dispose();
    _scroll.dispose();
    _speech.stop();
    _tts.stop();
    super.dispose();
  }

  String _localeForSpeech() {
    switch (_language) {
      case JarvisLanguage.persian:
        return 'fa-IR';
      case JarvisLanguage.english:
        return 'en-US';
      case JarvisLanguage.both:
        return 'fa-IR';
    }
  }

  Future<void> _toggleListening() async {
    if (_listening) {
      await _speech.stop();
      return;
    }
    if (!_speechReady) {
      await _initSpeech();
      if (!_speechReady) {
        _addMessage(
          'تشخیص صدا در گوشی آماده نیست. سرویس Speech Recognition و اینترنت/زبان آفلاین گوشی را بررسی کن.',
          false,
        );
        return;
      }
    }
    setState(() {
      _recognized = '';
      _status = 'LISTENING';
    });
    await _speech.listen(
      localeId: _localeForSpeech(),
      listenFor: const Duration(seconds: 25),
      pauseFor: const Duration(seconds: 3),
      onResult: (result) {
        if (!mounted) return;
        setState(() => _recognized = result.recognizedWords);
        if (result.finalResult && result.recognizedWords.trim().isNotEmpty) {
          _handleUserText(result.recognizedWords);
        }
      },
    );
  }

  void _addMessage(String text, bool fromUser) {
    setState(() => _messages.add(ChatLine(text, fromUser)));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _speak(String text, {bool english = false}) async {
    try {
      await _tts.stop();
      await _tts.setLanguage(english ? 'en-US' : 'fa-IR');
      await _tts.speak(text);
    } catch (_) {
      if (mounted) setState(() => _status = 'TTS VOICE NOT AVAILABLE');
    }
  }

  String _replyTo(String raw) {
    final q = raw.toLowerCase().trim();

    if (q.contains('ساعت') || q.contains('time')) {
      final now = DateTime.now();
      final time = '${now.hour.toString().padLeft(2, '0')}:'
          '${now.minute.toString().padLeft(2, '0')}';
      return _containsPersian(raw)
          ? 'الان ساعت $time است.'
          : 'The time is $time.';
    }

    if (q.contains('تاریخ') || q.contains('date') || q.contains('today')) {
      final now = DateTime.now();
      return _containsPersian(raw)
          ? 'تاریخ میلادی امروز ${now.year}/${now.month}/${now.day} است.'
          : 'Today is ${now.year}/${now.month}/${now.day}.';
    }

    if (q.contains('سلام') || q.contains('hello') || q.contains('hi')) {
      return _containsPersian(raw)
          ? 'سلام. JARVIS آماده دریافت فرمان است.'
          : 'Hello. JARVIS is ready for your command.';
    }

    if (q.contains('اسمت') || q.contains('نامت') || q.contains('your name')) {
      return _containsPersian(raw)
          ? 'من JARVIS هستم، دستیار هوشمند شما.'
          : 'I am JARVIS, your personal assistant.';
    }

    if (q.contains('کمک') || q.contains('help')) {
      return _containsPersian(raw)
          ? 'فعلاً می‌توانی ساعت، تاریخ، سلام و نام من را بپرسی. اتصال هوش مصنوعی آنلاین در نسخه بعدی اضافه می‌شود.'
          : 'For now, ask me the time, date, say hello, or ask my name. Online AI will be added in the next version.';
    }

    return _containsPersian(raw)
        ? 'فرمان دریافت شد: $raw. در نسخه اول هنوز به موتور هوش مصنوعی آنلاین متصل نیستم.'
        : 'Command received: $raw. In version 1, I am not connected to an online AI engine yet.';
  }

  bool _containsPersian(String value) {
    return RegExp(r'[\u0600-\u06FF]').hasMatch(value);
  }

  Future<void> _handleUserText(String text) async {
    final cleaned = text.trim();
    if (cleaned.isEmpty) return;
    _addMessage(cleaned, true);
    final reply = _replyTo(cleaned);
    _addMessage(reply, false);
    final persian = _containsPersian(reply);
    await _speak(reply, english: !persian);
    if (mounted) setState(() => _status = 'SYSTEM READY');
  }

  Future<void> _sendTyped() async {
    final text = _input.text.trim();
    if (text.isEmpty) return;
    _input.clear();
    await _handleUserText(text);
  }

  void _changeLanguage(JarvisLanguage? value) {
    if (value == null) return;
    setState(() => _language = value);
  }

  @override
  Widget build(BuildContext context) {
    final latest = _recognized.isNotEmpty
        ? _recognized
        : (_listening ? 'Listening...' : 'Tap the core to speak');

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        titleSpacing: 22,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('J.A.R.V.I.S', style: TextStyle(
              letterSpacing: 4, fontWeight: FontWeight.w700, fontSize: 18)),
            Text('PERSONAL AI INTERFACE', style: TextStyle(
              fontSize: 9, letterSpacing: 2, color: Color(0xFF70CDE5))),
          ],
        ),
        actions: [
          PopupMenuButton<JarvisLanguage>(
            icon: const Icon(Icons.language, color: Color(0xFF38D9FF)),
            onSelected: _changeLanguage,
            itemBuilder: (_) => const [
              PopupMenuItem(value: JarvisLanguage.both, child: Text('فارسی + English')),
              PopupMenuItem(value: JarvisLanguage.persian, child: Text('فارسی')),
              PopupMenuItem(value: JarvisLanguage.english, child: Text('English')),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 10),
            _buildStatus(),
            const SizedBox(height: 12),
            Expanded(
              flex: 5,
              child: Center(
                child: GestureDetector(
                  onTap: _toggleListening,
                  child: AnimatedBuilder(
                    animation: _pulse,
                    builder: (context, child) => Transform.scale(
                      scale: _listening ? _pulse.value : 1,
                      child: child,
                    ),
                    child: _buildCore(),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                latest,
                textAlign: TextAlign.center,
                maxLines: 2,
                style: const TextStyle(color: Color(0xFF8ADFF4), fontSize: 13),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              flex: 4,
              child: Container(
                margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF0A1626),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0xFF17445C)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: const [
                        Icon(Icons.forum_outlined, size: 16, color: Color(0xFF38D9FF)),
                        SizedBox(width: 8),
                        Text('COMMUNICATION LOG', style: TextStyle(
                          fontSize: 10, letterSpacing: 2, color: Color(0xFF8ADFF4))),
                      ],
                    ),
                    const Divider(color: Color(0xFF17364B)),
                    Expanded(
                      child: ListView.builder(
                        controller: _scroll,
                        itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final item = _messages[index];
                          return Align(
                            alignment: item.fromUser
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Container(
                              constraints: const BoxConstraints(maxWidth: 290),
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 9),
                              decoration: BoxDecoration(
                                color: item.fromUser
                                    ? const Color(0xFF10334A)
                                    : const Color(0xFF101F32),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: item.fromUser
                                      ? const Color(0xFF17617B)
                                      : const Color(0xFF1A3A50)),
                              ),
                              child: Text(item.text, style: const TextStyle(
                                fontSize: 13, height: 1.4)),
                            ),
                          );
                        },
                      ),
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _input,
                            onSubmitted: (_) => _sendTyped(),
                            decoration: InputDecoration(
                              hintText: 'Message JARVIS...',
                              hintStyle: const TextStyle(color: Colors.white38),
                              filled: true,
                              fillColor: const Color(0xFF06101D),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(24),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton.filled(
                          onPressed: _sendTyped,
                          icon: const Icon(Icons.arrow_upward),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                'JARVIS MOBILE  •  VERSION 1.0  •  ${_isPersian ? "FA" : _language == JarvisLanguage.english ? "EN" : "FA + EN"}',
                style: const TextStyle(
                  color: Colors.white30, fontSize: 9, letterSpacing: 1.4),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatus() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: const Color(0xFF0A1B2B),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0xFF17445C)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 7, height: 7,
            decoration: BoxDecoration(
              color: _listening ? Colors.orangeAccent : const Color(0xFF35E6B2),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: (_listening ? Colors.orangeAccent : const Color(0xFF35E6B2))
                      .withOpacity(0.7),
                  blurRadius: 8,
                )
              ],
            ),
          ),
          const SizedBox(width: 9),
          Text(_status, style: const TextStyle(
            fontSize: 10, letterSpacing: 2, color: Color(0xFF9CEBFA))),
        ],
      ),
    );
  }

  Widget _buildCore() {
    return Container(
      width: 220,
      height: 220,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            const Color(0xFF1AAED0).withOpacity(0.28),
            const Color(0xFF0B3150).withOpacity(0.16),
            Colors.transparent,
          ],
        ),
        border: Border.all(color: const Color(0xFF1C9FC5), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00BCEB).withOpacity(0.22),
            blurRadius: 35,
            spreadRadius: 8,
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: 172, height: 172,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFF176D91), width: 1),
            ),
          ),
          Container(
            width: 132, height: 132,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const RadialGradient(
                colors: [Color(0xFF1D779A), Color(0xFF09243B), Color(0xFF06111F)],
              ),
              border: Border.all(color: const Color(0xFF55DFFF), width: 1.5),
              boxShadow: const [
                BoxShadow(color: Color(0x5538D9FF), blurRadius: 24, spreadRadius: 3),
              ],
            ),
            child: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.memory, size: 42, color: Color(0xFFB8F4FF)),
                SizedBox(height: 5),
                Text('J.A.R.V.I.S', style: TextStyle(
                  color: Colors.white, fontSize: 11, letterSpacing: 2)),
              ],
            ),
          ),
          Positioned(
            top: 20, right: 42,
            child: _dot(5),
          ),
          Positioned(
            bottom: 28, left: 35,
            child: _dot(4),
          ),
        ],
      ),
    );
  }

  Widget _dot(double size) => Container(
    width: size, height: size,
    decoration: const BoxDecoration(
      color: Color(0xFF74E9FF), shape: BoxShape.circle),
  );
}
